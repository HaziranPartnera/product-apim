var customConsentTempalte1 =
    "<div class='consent-container-1'>We need your {{pii:Test Purposes:Department}} , {{pii:Test" +
    " Purposes:Country}} . Optionally we need {{pii:Test Purposes:Last Name}} and {{pii:Test Purposes:Gender}} for" +
    " {{purpose:Test Purposes}}.</div></div>";
