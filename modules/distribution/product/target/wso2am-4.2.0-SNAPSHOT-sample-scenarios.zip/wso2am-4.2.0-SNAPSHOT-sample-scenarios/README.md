# APIM Sample Scenarios

## How to run
1. Download wso2am-2.6.0-SNAPSHOT-sample-scenarios.zip file.
2. Unzip and Copy sample-scenarios folder to <APIM_HOME> folder.
3. Run the <APIM_HOME>/sample-scenarios/run.sh file.
`bash run.sh`

